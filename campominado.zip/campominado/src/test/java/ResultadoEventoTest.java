import br.com.cod3r.cm.modelo.*;
import br.com.cod3r.cm.visao.BotaoCampo;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import static org.junit.jupiter.api.Assertions.*;

public class ResultadoEventoTest {

    @Test
    public void testGanhouTrue() {
        // Arrange
        ResultadoEvento resultado = new ResultadoEvento(true);

        // Act
        boolean ganhou = resultado.isGanhou();

        // Assert
        assertTrue(ganhou);
    }

    @Test
    public void testGanhouFalse() {
        // Arrange
        ResultadoEvento resultado = new ResultadoEvento(false);

        // Act
        boolean ganhou = resultado.isGanhou();

        // Assert
        assertFalse(ganhou);
    }

    @Test
    public void testConstrutor() {
        // Arrange
        boolean ganhou = true;

        // Act
        ResultadoEvento resultado = new ResultadoEvento(ganhou);

        // Assert
        assertNotNull(resultado);
    }

    @Test
    public void testConstrutorComFalse() {
        // Arrange
        boolean ganhou = false;

        // Act
        ResultadoEvento resultado = new ResultadoEvento(ganhou);

        // Assert
        assertNotNull(resultado);
    }

    @Test
    public void testAdicionarVizinho() {
        Campo campo1 = new Campo(0, 0);
        Campo campo2 = new Campo(1, 1);
        Campo campo3 = new Campo(0, 1);
        Campo campo4 = new Campo(2, 2);

        assertTrue(campo1.adicionarVizinho(campo2));
        assertTrue(campo1.adicionarVizinho(campo3));
        assertFalse(campo1.adicionarVizinho(campo4));
    }

    @Test
    public void testMetodoReiniciar() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.abrir(0, 0);
        tabuleiro.abrir(1, 1);
        tabuleiro.reiniciar();

    }

    @Test
    public void testMetodoAlternarMarcacao() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.alternarMarcacao(0, 0);
    }

    @Test
    public void testMetodoAbrir() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        tabuleiro.abrir(0, 0);
    }

    @Test
    public void testConstrutorAtribuicoes() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        assertEquals(5, tabuleiro.getLinhas());
        assertEquals(5, tabuleiro.getColunas());
    }

    @Test
    public void testMetodoObjetivoAlcancado() {
        Tabuleiro tabuleiro = new Tabuleiro(5, 5, 5);
        assertFalse(tabuleiro.objetivoAlcancado());
    }


    @Test
    public void testEstadoDoCampo() {
        Campo campo = new Campo(0, 0);
        assertFalse(campo.isMarcado());
        assertTrue(campo.isDesmarcado());
        assertFalse(campo.isAberto());
        assertTrue(campo.isFechado());
        assertFalse(campo.isMinado());
        assertTrue(campo.isSemMina());
        campo.alternarMarcacao();
        assertTrue(campo.isMarcado());
        assertFalse(campo.isDesmarcado());
        campo.setAberto(true);
        assertTrue(campo.isAberto());
        assertFalse(campo.isFechado());
    }

    @Test
    public void testGettersLinhaColuna() {
        Campo campo = new Campo(3, 4);
        assertEquals(3, campo.getLinha());
        assertEquals(4, campo.getColuna());
    }

    @Test
    public void testReiniciar() {
        Campo campo = new Campo(0, 0);
        campo.setAberto(true);
        campo.minar();
        campo.alternarMarcacao();
        campo.reiniciar();
        assertFalse(campo.isAberto());
        assertFalse(campo.isMinado());
        assertFalse(campo.isMarcado());
    }

    @Test
    public void testMinasNaVizinhanca() {
        Campo campo = new Campo(0, 0);
        Campo vizinho1 = new Campo(0, 1);
        vizinho1.minar();
        Campo vizinho2 = new Campo(1, 0);
        vizinho2.minar();
        campo.adicionarVizinho(vizinho1);
        campo.adicionarVizinho(vizinho2);
        assertEquals(2, campo.minasNaVizinhanca());
    }

    @Test
    public void testObjetivoAlcancadoDesvendado() {
        Campo campo = new Campo(0, 0);
        campo.setAberto(true);
        assertFalse(campo.isMinado());
        assertTrue(campo.objetivoAlcancado());
    }

    @Test
    public void testObjetivoAlcancadoProtegido() {
        Campo campo = new Campo(0, 0);
        campo.minar();
        campo.alternarMarcacao();
        assertTrue(campo.objetivoAlcancado());
    }

    @Test
    public void testObjetivoNaoAlcancado() {
        Campo campo = new Campo(0, 0);
        assertFalse(campo.objetivoAlcancado());
    }

    @Test
    public void testAlternarMarcacaoMarcadoParaDesmarcado() {
        Campo campo = new Campo(0, 0);
        assertFalse(campo.isMarcado());
        campo.alternarMarcacao();
        assertTrue(campo.isMarcado());
    }

    @Test
    public void testAlternarMarcacaoDesmarcadoParaMarcado() {
        Campo campo = new Campo(0, 0);
        campo.alternarMarcacao();
        assertTrue(campo.isMarcado());
        campo.alternarMarcacao();
    }

    @Test
    public void testAbrirCampoNaoMarcadoNaoAbertoNaoMinado() {
        Campo campo = new Campo(0, 0);
        assertTrue(campo.abrir());
        assertTrue(campo.isAberto());
    }

    @Test
    public void testAbrirCampoNaoMarcadoNaoAbertoMinado() {
        Campo campo = new Campo(0, 0);
        campo.minar();
        assertTrue(campo.abrir());
        assertFalse(campo.isAberto());
    }

    @Test
    public void testAbrirCampoJaMarcado() {
        Campo campo = new Campo(0, 0);
        campo.alternarMarcacao();
        assertFalse(campo.abrir());
        assertFalse(campo.isAberto());
    }

    @Test
    public void testNotificarObservadoresExplosao() {
        Campo campo = new Campo(0, 0);
        campo.minar();
        boolean[] eventoOcorreu = {false};
        CampoObservador observador = new CampoObservador() {
            @Override
            public void eventoOcorreu(Campo campo, CampoEvento evento) {
                if (evento == CampoEvento.EXPLODIR) {
                    eventoOcorreu[0] = true;
                }
            }
        };
    }

    @Test
    public void testEventoOcorreuObjetivoAlcancado() {
        Campo campo = new Campo(0, 0);
        boolean[] eventoExplosao = {false};
        boolean[] eventoObjetivoAlcancado = {false};

        CampoObservador observador = new CampoObservador() {
            @Override
            public void eventoOcorreu(Campo campo, CampoEvento evento) {
                if (evento == CampoEvento.EXPLODIR) {
                    eventoExplosao[0] = true;
                } else if (evento == CampoEvento.ABRIR) {
                    eventoObjetivoAlcancado[0] = true;
                }
            }
        };

    }

    @Test
    public void testEventoOcorreuExplosao32() {
        Campo campo = new Campo(0, 0);
        boolean[] eventoExplosao = {false};
        boolean[] eventoObjetivoAlcancado = {false};

        CampoObservador observador = new CampoObservador() {
            @Override
            public void eventoOcorreu(Campo campo, CampoEvento evento) {
                if (evento == CampoEvento.EXPLODIR) {
                    eventoExplosao[0] = true;
                } else if (evento == CampoEvento.ABRIR) {
                    eventoObjetivoAlcancado[0] = true;
                }
            }
        };
    }



    @Test
    public void testParaCadaCampo() {
       Campo campo1 = new Campo(0, 0);
       Campo campo2 = new Campo(0, 1);
       Campo campo3 = new Campo(1, 0);
       List<Campo> camposVisitados = new ArrayList<>();
       List<Campo> campos = List.of(campo1, campo2, campo3);
       Consumer<Campo> funcao = campo -> {
           campo.setAberto(true);
           camposVisitados.add(campo);
       };
       campos.forEach(funcao);
       assertEquals(3, camposVisitados.size());
       assertTrue(camposVisitados.contains(campo1));
       assertTrue(camposVisitados.contains(campo2));
       assertTrue(camposVisitados.contains(campo3));
        }


    @Test
    public void testNotificarObservadores() {
        Tabuleiro tabuleiro = new Tabuleiro(3, 3, 2);

        List<ResultadoEvento> eventos = new ArrayList<>();

        Consumer<ResultadoEvento> observador = eventos::add;

        tabuleiro.registrarObservador(observador);
        tabuleiro.notificarObservadores(false);

        assertEquals(1, eventos.size());
    }

    @Test
    public void testRegistrarObservador() {
        Tabuleiro tabuleiro = new Tabuleiro(3, 3, 2);
        ObservadorTest observadorTest = new ObservadorTest();
        tabuleiro.registrarObservador(observadorTest);
        tabuleiro.notificarObservadores(false);
        assertTrue(observadorTest.foiNotificado());
    }

    static class ObservadorTest implements Consumer<ResultadoEvento> {
        private boolean notificado = false;

        @Override
        public void accept(ResultadoEvento resultadoEvento) {
            notificado = true;
        }

        public boolean foiNotificado() {
            return notificado;
        }
    }

    @Test
    public void testMostrarMinas() {
        Tabuleiro tabuleiro = new Tabuleiro(3, 3, 2);
        Campo[] campos = new Campo[tabuleiro.getLinhas() * tabuleiro.getColunas()];
        final int[] index = {0};
        tabuleiro.paraCadaCampo(c -> {
            campos[index[0]] = c;
            index[0]++;
        });
        campos[0].minar();
        campos[4].minar();
        campos[8].minar();
        campos[0].alternarMarcacao();

        tabuleiro.mostrarMinas();

        assertFalse(campos[0].isAberto());
        assertTrue(campos[4].isAberto());
        assertTrue(campos[8].isAberto());
    }

    @Test
    public void testEventoOcorreuExplosao() {
        Tabuleiro tabuleiro = new Tabuleiro(3, 3, 2);
        List<ResultadoEvento> eventos = new ArrayList<>();
        Consumer<ResultadoEvento> observador = eventos::add;
        tabuleiro.registrarObservador(observador);
        tabuleiro.paraCadaCampo(campo -> {
            if (campo.isMinado()) {
                tabuleiro.eventoOcorreu(campo, CampoEvento.EXPLODIR);
            }
        });

        tabuleiro.paraCadaCampo(campo -> {
            if (campo.isMinado()) {
                assertTrue(campo.isAberto());
                assertFalse(campo.isMarcado());
            }
        });

        assertFalse(eventos.isEmpty());
        assertFalse((BooleanSupplier) eventos.get(0));
    }




}




