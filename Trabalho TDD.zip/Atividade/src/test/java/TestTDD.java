import org.example.classes.ListaDeTarefas;
import org.example.classes.Tarefa;
import org.junit.Test;
import static org.junit.Assert.*;

public class TestTDD {
    @Test
    public void testAdicionarTarefa() {
        ListaDeTarefas listaTarefas = new ListaDeTarefas();
        listaTarefas.adicionarTarefa("Comprar mantimentos", "Leite, ovos, pão");
        assertEquals(1, listaTarefas.obterTarefas().size());
    }

    @Test
    public void testMarcarTarefaConcluida() {
        ListaDeTarefas listaTarefas = new ListaDeTarefas();
        listaTarefas.adicionarTarefa("Estudar para o exame", "Capítulos 1-5");
        Tarefa tarefa = listaTarefas.obterTarefas().get(0);

        assertFalse(tarefa.isConcluida()); // Certifique-se de que a tarefa não está concluída inicialmente

        listaTarefas.marcarTarefaConcluida(tarefa);
        assertTrue(tarefa.isConcluida());
    }

    @Test
    public void testEditarTarefa() {
        ListaDeTarefas listaTarefas = new ListaDeTarefas();
        listaTarefas.adicionarTarefa("Fazer exercícios", "30 minutos de cardio");
        Tarefa tarefa = listaTarefas.obterTarefas().get(0);

        listaTarefas.editarTarefa(tarefa, "Fazer exercícios aeróbicos", "30 minutos de corrida");
        assertEquals("Fazer exercícios aeróbicos", tarefa.getNome());
        assertEquals("30 minutos de corrida", tarefa.getDescricao());
    }


    @Test
    public void testExcluirTarefa() {
        ListaDeTarefas listaTarefas = new ListaDeTarefas();
        listaTarefas.adicionarTarefa("Limpar o escritório", "Organizar papéis");
        Tarefa tarefa = listaTarefas.obterTarefas().get(0);

        listaTarefas.excluirTarefa(tarefa);
        assertEquals(0, listaTarefas.obterTarefas().size());
    }
}
