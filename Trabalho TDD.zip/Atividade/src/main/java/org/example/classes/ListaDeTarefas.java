package org.example.classes;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ListaDeTarefas {
    private List<Tarefa> tarefas;

    public ListaDeTarefas() {
        this.tarefas = new ArrayList<>();
    }

    public void adicionarTarefa(String nome, String descricao) {
        Tarefa novaTarefa = new Tarefa(nome, descricao);
        tarefas.add(novaTarefa);
    }

    public List<Tarefa> obterTarefas() {
        return new ArrayList<>(tarefas);
    }

    public void marcarTarefaConcluida(Tarefa tarefa) {
        tarefa.setConcluida(true);
    }

    public void editarTarefa(Tarefa tarefa, String novoNome, String novaDescricao) {
        tarefa.setNome(novoNome);
        tarefa.setDescricao(novaDescricao);
    }

    public void excluirTarefa(Tarefa tarefa) {
        tarefas.remove(tarefa);
    }
}
